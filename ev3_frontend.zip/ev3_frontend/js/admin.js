// Creación de la "base de datos"
let baseDeDatos = [
    { id: 0, nombre: "Monitor", precio: 120000, imagen: "../img/monitor.png" },
    { id: 1, nombre: "Mouse", precio: 50000, imagen: "../img/mouseGamer.png" },
    { id: 2, nombre: "MousePad", precio: 10000, imagen: "../img/mousepad.png" },
    { id: 3, nombre: "Procesador", precio: 90000, imagen: "../img/procesador.png" },
    { id: 4, nombre: "Tarjeta gráfica", precio: 300000, imagen: "../img/tarjetaGrafica.png" },
    { id: 5, nombre: "Placa Madre", precio: 120000, imagen: "../img/placaMadre.png" },
    { id: 6, nombre: "Fuente de poder", precio: 60000, imagen: "../img/fuentePoder.png" },
    { id: 7, nombre: "Ram", precio: 16000, imagen: "../img/ram.png" }
];

// Definición del objeto producto
const objProducto = {
    id: "",
    nombre: "",
    precio: 0,
    imagen: ""
}

let editando = false;

const formulario = document.querySelector('#formulario');
const nombreInput = document.querySelector('#nombre');
const precioInput = document.querySelector('#precio');
const btnAgregar = document.querySelector('#btnAgregar');

formulario.addEventListener('submit', validarFormulario);

function validarFormulario(e) {
    e.preventDefault();

    if (nombreInput.value === '' || precioInput.value === '') {
        alert("ERROR: ¡Debes llenar todos los campos!");
        return;
    }

    if (editando) {
        editarProducto();
        editando = false;
    } else {
        objProducto.id = Date.now();
        objProducto.nombre = nombreInput.value;
        objProducto.precio = parseFloat(precioInput.value);
        agregarProducto();
    }
}

function agregarProducto() {
    baseDeDatos.push({ ...objProducto });
    mostrarProductos();

    formulario.reset();
    limpiarObjeto();
}

function limpiarObjeto() {
    objProducto.id = '';
    objProducto.nombre = '';
    objProducto.precio = 0;
}

function mostrarProductos() {
    const divProductos = document.querySelector('.div-productos');
    limpiarHTML();

    baseDeDatos.forEach(producto => {
        const { id, nombre, precio, imagen } = producto;

        const parrafo = document.createElement('p');
        parrafo.textContent = `|${id} | ${nombre} | ${precio} |`;
        parrafo.dataset.id = id;

        const editarBoton = document.createElement('button');
        editarBoton.onclick = () => cargarProducto(producto);
        editarBoton.textContent = 'Editar';
        editarBoton.classList.add('btn', 'btn-editar');
        parrafo.append(editarBoton);

        const eliminarBoton = document.createElement('button');
        eliminarBoton.onclick = () => eliminarProducto(id);
        eliminarBoton.textContent = 'Eliminar';
        eliminarBoton.classList.add('btn', 'btn-eliminar');
        parrafo.append(eliminarBoton);

        const hr = document.createElement('hr');

        divProductos.appendChild(parrafo);
        divProductos.appendChild(hr);
    });
}

function cargarProducto(producto) {
    const { id, nombre, precio } = producto;

    nombreInput.value = nombre;
    precioInput.value = precio;

    objProducto.id = id;

    formulario.querySelector('button[type="submit"]').textContent = 'Actualizar';

    editando = true;
}

function editarProducto() {
    objProducto.nombre = nombreInput.value;
    objProducto.precio = parseFloat(precioInput.value);

    baseDeDatos = baseDeDatos.map(producto => {
        if (producto.id === objProducto.id) {
            producto.nombre = objProducto.nombre;
            producto.precio = objProducto.precio;
        }
        return producto;
    });

    limpiarHTML();
    mostrarProductos();

    formulario.reset();
    formulario.querySelector('button[type="submit"]').textContent = 'Agregar';
    editando = false;
}

function eliminarProducto(id) {
    baseDeDatos = baseDeDatos.filter(producto => producto.id !== id);
    limpiarHTML();
    mostrarProductos();
}

function limpiarHTML() {
    const divProductos = document.querySelector('.div-productos');
    while (divProductos.firstChild) {
        divProductos.removeChild(divProductos.firstChild);
    }
}

// Inicializar la lista de productos al cargar la página
mostrarProductos();



//volver al login
function irLoginAdmin(){
    location.href ="login.html";
};